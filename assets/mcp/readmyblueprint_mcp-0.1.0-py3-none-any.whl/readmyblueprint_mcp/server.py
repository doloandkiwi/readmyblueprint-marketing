"""MCP server exposing a customer's own ReadMyBlueprint documents and material
summaries to an MCP client (Claude Desktop, Claude Code, etc.) via natural
language -- e.g. "what materials did my last upload need?"

This is a thin wrapper around the existing public read-only API
(backend/app/routes/api.py) -- it adds no new capability and no new data
access beyond what that API already exposes with an account's own API key.
Runs locally on the customer's machine (an MCP server is a local process an
MCP client launches, not something we host), so their API key never leaves
their own computer except in requests to api.readmyblueprint.com they
already trust.

Auth and base URL come from environment variables, set in the MCP client's
own config (see README.md) -- never hardcoded, never asked for as a tool
argument (an argument would let the key leak into a client's own chat log).
"""

import os

import httpx
from mcp.server.fastmcp import FastMCP

API_BASE = os.environ.get("READMYBLUEPRINT_API_BASE", "https://readmyblueprint.onrender.com").rstrip("/")
API_KEY = os.environ.get("READMYBLUEPRINT_API_KEY")

mcp = FastMCP("readmyblueprint")


def _request(path: str) -> dict | list:
    if not API_KEY:
        raise RuntimeError(
            "READMYBLUEPRINT_API_KEY is not set. Generate a key from the API Access panel "
            "at app.readmyblueprint.com, then add it to this MCP server's env config."
        )
    resp = httpx.get(
        f"{API_BASE}{path}",
        headers={"Authorization": f"Bearer {API_KEY}"},
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()


@mcp.tool()
def list_documents() -> list[dict]:
    """List the account's uploaded plan sets: id, filename, page count, and upload date.
    Use this first to find a document's id before calling get_document_summary."""
    return _request("/api/v1/documents")


@mcp.tool()
def get_document_summary(document_id: int) -> list[dict]:
    """Get the material takeoff summary for one document by id -- one row per
    material with its summed quantity, the same numbers shown in the app's
    results table and CSV export. Call list_documents first if you don't
    already have the id."""
    return _request(f"/api/v1/documents/{document_id}/summary")


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
